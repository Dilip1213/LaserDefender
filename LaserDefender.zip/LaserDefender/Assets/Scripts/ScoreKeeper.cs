using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ScoreKeeper : MonoBehaviour
{
    public static int score = 0;
    private Text mytext;

    void Start()
    {
        mytext = GetComponent<Text>();
        Reset();
    }

   public void Score(int points)
    {
        Debug.Log("Scored points");
        score += points;
        mytext.text = score.ToString();
    }
   public static void Reset()
    {
        score = 0;
      //  mytext.text = score.ToString();

    }

}
