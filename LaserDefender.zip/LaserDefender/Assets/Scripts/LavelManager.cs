using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class LavelManager : MonoBehaviour
{

	public void LoadLevel(string name)
	{
		Debug.Log ("Level load reqested: "+name);
	//	Brick.breakableCount = 0;
		SceneManager.LoadScene (name);
	}
	public void QuitRequest(){
		Debug.Log("I Want to quit!");
		Application.Quit ();
	}
    //public void LoadNextLevel()
    //{
    //    //Brick.breakableCount = 0;
    //    //Application.LoadLevel (Application.loadedLevel + 1);
    //    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    //}
    /*public void BrickDestroyed()
	{
		if(Brick.breakableCount <= 0) //when last brick destroyed
			{
				LoadNextLevel();
			}
	} */
}
